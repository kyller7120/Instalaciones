import pandas as pd
import mysql.connector

# Lee el archivo de Excel y lo convierte en un DataFrame de pandas
df = pd.read_excel('C:\\Users\\river\\Documents\\pandemia.xlsx')

# Conecta a la base de datos
conexion = mysql.connector.connect(
    host='localhost',
    user='root',
    password='',
    database='prueba'
)

# Crea un cursor para ejecutar las consultas
cursor = conexion.cursor()

# Recorre el DataFrame e inserta los datos en la base de datos
for index, row in df.iterrows():
    consulta = "INSERT INTO datos_pandemia (Universidad, Carrera, Cantidad) VALUES (%s, %s, %s)"
    valores = (row['Universidad'], row['Carrera'], row['Cantidad'])
    cursor.execute(consulta, valores)

# Guarda los cambios y cierra la conexión
conexion.commit()
conexion.close()
